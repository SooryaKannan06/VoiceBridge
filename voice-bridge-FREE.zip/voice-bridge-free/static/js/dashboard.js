// Dashboard JavaScript

const createRoomBtn = document.getElementById('createRoomBtn');
const roomCodeDisplay = document.getElementById('roomCodeDisplay');
const roomCodeText = document.getElementById('roomCodeText');
const joinRoomBtn = document.getElementById('joinRoomBtn');
const joinExistingBtn = document.getElementById('joinExistingBtn');
const joinCodeInput = document.getElementById('joinCode');

createRoomBtn.addEventListener('click', async () => {
    try {
        const response = await fetch('/create-room', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        const data = await response.json();

        if (data.success) {
            roomCodeText.textContent = data.room_code;
            roomCodeDisplay.classList.remove('d-none');
            createRoomBtn.disabled = true;
        }
    } catch (error) {
        alert('Failed to create room. Please try again.');
    }
});

joinRoomBtn.addEventListener('click', () => {
    const code = roomCodeText.textContent;
    if (code) {
        window.location.href = `/call/${code}`;
    }
});

joinExistingBtn.addEventListener('click', () => {
    const code = joinCodeInput.value.trim();
    if (code) {
        window.location.href = `/call/${code}`;
    } else {
        alert('Please enter a room code');
    }
});

joinCodeInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        joinExistingBtn.click();
    }
});